import requests
import json
import time
from selenium import webdriver
import selenium.webdriver.support.ui as ui

# def login_query_10010(username, pwd, CK):
#         driver = webdriver.Chrome()
#         driver.get("http://iservice.10010.com/e4/")
#         wait = ui.WebDriverWait(driver, 10)
#         login_frame = driver.find_element_by_xpath("html/body/div[5]/div[1]/iframe")
#         driver.switch_to_frame(login_frame);
#         wait.until(lambda dr: dr.find_element_by_id('userName').is_displayed())
#         driver.find_element_by_id("userName").send_keys(username)
#         driver.find_element_by_id("userPwd").send_keys(pwd)
#         wait.until(lambda dr: dr.find_element_by_id('randomCKCode').is_displayed())
#         driver.find_element_by_id('randomCKCode').click()
#         driver.find_element_by_id('userCK').send_keys(CK)
#         time.sleep(20)
#         wait.until(lambda dr: dr.find_element_by_id('login1').is_displayed())
#         driver.find_element_by_id("login1").click()
#         time.sleep(5)
#         driver.switch_to_default_content()
#         wait.until(lambda dr: dr.find_element_by_id('menu_query').is_displayed())
#         driver.find_element_by_id('menu_query"]').click()
#         time.sleep(5)
#         wait.until(lambda dr: driver.find_element_by_xpath('//*[@id="000100030001"]').is_displayed())
#         driver.find_element_by_xpath('//*[@id="000100030001"]').click()
#         time.sleep(5)
#         wait.until(lambda dr: dr.find_element_by_id('huoqu_buttons').is_displayed())
#         driver.find_element_by_id('huoqu_buttons"]').click()
#         time.sleep(30)
#         driver.quit()
#
#
# if __name__ == '__main__':
#         # user = User()
#         # username1 = input('请输入用户名：')
#         # password1 = input('请输入密码：')
#         # Verification = input('请输入验证码：')
#         login_query_10010(17600824539, 159357, '')








# def login_10010(username,password):
#     dr = webdriver.Chrome()
#     dr.get('http://www.10010.com/bj/?WT.mc_id=beijing_jtpcpinzhuan_1708_ltbaidupcpinzhuan_title&utm_source=baidu&utm_medium=cpc&utm_term=&utm_campaign=beijing_jtpcpinzhuan_1708_ltbaidupcpinzhuan_title')
#     time.sleep(5)
#     # dr.maximize_window()
#     dr.find_element_by_xpath('//*[@id="234784"]/div/div/ul[2]/li[2]/div[1]/h3/a').click()
#     # time.sleep(10)
#     wait = ui.WebDriverWait(dr, 10)
#     login_frame = dr.find_element_by_xpath("html/body/div[5]/div[1]/iframe")
#     dr.switch_to_frame(login_frame);
#     wait.until(lambda dr: dr.find_element_by_id('userName').is_displayed())
#     dr.find_element_by_id('userName').send_keys(username)
#     dr.find_element_by_id('userPwd').send_keys(password)
#     time.sleep(15)
#     dr.quit()
# if __name__ == '__main__':
#     login_10010('17600824539','159357')







# from selenium import webdriver
# import time
# #模拟登陆微博
# driver = webdriver.Chrome()
# driver.get('https://www.weibo.com')
# time.sleep(10)
# driver.find_element_by_id('loginname').send_keys('1487399190@qq.com')
# driver.find_element_by_css_selector('.info_list.password input[node-type="password"]').send_keys('77ben1997730')
# driver.find_element_by_css_selector('.info_list.login_btn a[node-type="submitBtn"]').click()
# driver.execute_script("window.scrollTo(0,document.body.scrollHeight); var lenOfPage=document.body.scrollHeight; return lenOfPage;")
# driver.quit() #退出





# header = {
#
#     'Cookie': 'gipgeo=18|185; WT.mc_id=beijing_jtpcpinzhuan_1708_ltbaidupcpinzhuan_title; WT_FPC=id=27492c1b676e52d4a0e1512364955327:lv=1512364955330:ss=1512364955327; Hm_lvt_9208c8c641bfb0560ce7884c36938d9d=1512364955; Hm_lpvt_9208c8c641bfb0560ce7884c36938d9d=1512364955; _ga=GA1.2.974306504.1512364956; _gid=GA1.2.56120121.1512364956; ang_sessionid=873650641388107110; ang_catchyou=1; ang_seqid=4; piw=%7B%22login_name%22%3A%22176****4539%22%2C%22nickName%22%3A%22%E8%A2%81%E5%B0%91%E8%88%AA%22%2C%22rme%22%3A%7B%22ac%22%3A%22%22%2C%22at%22%3A%22%22%2C%22pt%22%3A%2201%22%2C%22u%22%3A%2217600824539%22%7D%2C%22verifyState%22%3A%22%22%7D; JUT=jmj6/1JEAH4aHnUp0jZ9h5O1Y6m4I8VEaNmNEGILKC3bKZuYdNm03IHxKdNMUyUab1ALAawEf+CyUc62MuO38sdkpfl8D9cBtuCAfUtuMPRnmVfnNZTbbBUYNPD2ZoZX4sSLBz22XUZSZ0QO4yhNVs3z7jeabfhM2w/SLvb1a4DmEhaXikY5IWK/Mx70sTKcta70y7+Wh57DXtiV6LhXXZC8CFhNGG86IkyrWLDojEDJ2Hpqhw2BWSsTMeqZ7Wi03mZG5qz2MeBaFeplEgHdOZl3xBEsCoUc+Z9Na/tOcG8YbQa5jdU9ZFeELM9iJ7Miw+WTBIsAz1Fqsiz5+Z1DngThkFrkD4Ccjxtj5qsklJoXiFANHXNBuXwMaoGCnD9oHHdSL3TNNayh9nBf0FNfeebn2j4C0UD/oLke8wGjRSZTYp7BGEPQGr34wix0+pAT8r7ca1670MX87cighXGVYGB4cXLKOhESe1UmTpTHFXEO1RFMhOPcaPt0E9xxPByjlH7vv/XAT8h2zbTGTCV3sZYZDMwaUFVkcd2de1ZW1AnnvzCPBZbjEg==; _uop_id=d220533dc9de2533799e86d1533317ba; mallcity=18|188; _n3fa_cid=1cad7b425d6a42dfce81a2befabbd1b1; _n3fa_ext=ft=1512364952; _n3fa_lvt_a9e72dfe4a54a20c3d6e671b3bad01d9=1512364952; _n3fa_lpvt_a9e72dfe4a54a20c3d6e671b3bad01d9=1512364989; SHOP_PROV_CITY=; route=018cdcdd6813a57f1b516b8c4b1a030f; e3=ym0vhkcLQwLT64JCLhnvHbVBk4kTkzVhJpnnbX3WzTQpBp5gM6cD!-1728596300; MII=000100030001',
#     'Host': 'iservice.10010.com',
#     'Referer': 'http://www.10010.com/bj/',
#     'Upgrade-Insecure-Requests': '1',
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'}
#
# url = 'http://iservice.10010.com/e3/static/query/callDetail?_=1512041547133&accessURL=http://iservice.10010.com/e4/query/bill/call_dan-iframe.html?menuCode=000100030001&menuid=000100030001'
#
# data = {
#     'pageNo': '1',
#     'pageSize': '100',
#     'beginDate': '20171101',
#     'endDate': '20171130'
# }
# content = requests.post(url, headers=header, data=data)
# dict = json.loads(content.text)
# lists = []
# for i in dict['pageMap']['result']:
#     lists.append(i)
#     print(len(lists))
#     print(i)








# -*- coding: utf-8 -*-
from selenium import webdriver
import selenium.webdriver.support.ui as ui

def login_query_10010(username,pwd,CK):
    driver = webdriver.Chrome()
    driver.get("http://iservice.10010.com/e4/")
    wait = ui.WebDriverWait(driver, 10)
    login_frame = driver.find_element_by_xpath("html/body/div[5]/div[1]/iframe")
    driver.switch_to_frame(login_frame);
    wait.until(lambda dr: dr.find_element_by_id('userName').is_displayed())
    driver.find_element_by_id("userName").send_keys(username)
    driver.find_element_by_id("userPwd").send_keys(pwd)
    wait.until(lambda dr: dr.find_element_by_id('randomCKCode').is_displayed())
    driver.find_element_by_id('randomCKCode').click()
    # driver.find_element_by_id('userCK').send_keys(CK)
    driver.find_element_by_id('userCK').send_keys(CK)
    time.sleep(20)
    wait.until(lambda dr: dr.find_element_by_id('login1').is_displayed())
    driver.find_element_by_id("login1").click()
    # time.sleep(5)
    # driver.find_element_by_id("login1").click()
    driver.switch_to_default_content()
    wait.until(lambda dr: dr.find_element_by_id('menu_query').is_displayed())
    driver.find_element_by_id("menu_query").click()
    wait.until(lambda dr: dr.find_element_by_id('000100030001').is_displayed())
    driver.find_element_by_id("000100030001").click()
    wait.until(lambda dr: dr.find_element_by_id('huoqu_buttons').is_displayed())
    driver.find_element_by_id('huoqu_buttons').click()
    time.sleep(15)
    wait.until(lambda dr: dr.find_element_by_id('sign_in').is_displayed())
    driver.find_element_by_id('sign_in').click()

    # 'sign_in'
    # '//*[@id="callDetailContent"]/table'
    wait.until(lambda dr: dr.find_element_by_xpath('//*[@id="callDetailContent"]/table').is_displayed())
    contents = driver.find_element_by_xpath('//*[@id="callDetailContent"]/table').text
    lists = []
    lists.append(contents)

    print(contents)



    # wait.until(lambda dr: dr.find_element_by_xpath(".//*[@id='loadPage']/iframe").is_displayed())
    # account_info_frame = driver.find_element_by_xpath(".//*[@id='loadPage']/iframe")
    # driver.switch_to_frame(account_info_frame);
    # wait.until(lambda dr: dr.find_element_by_id('userInfoContent').is_displayed())
    # wait.until(lambda dr: dr.find_element_by_xpath(".//*[@id='userInfoContent']/dl[3]/dd").is_displayed())
    # phone_number = driver.find_element_by_xpath(".//*[@id='userInfoContent']/dl[3]/dd").text
    # print(u"电话号："+phone_number)
    # wait.until(lambda dr: dr.find_element_by_xpath(".//*[@id='userInfoContent']/dl[4]/dd").is_displayed())
    # available_amount = driver.find_element_by_xpath(".//*[@id='userInfoContent']/dl[4]/dd").text
    # print(u"可用预存款："+available_amount)

if __name__ == '__main__':
    login_query_10010("17600238137","159357",'')