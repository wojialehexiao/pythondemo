# -*- coding-8 -*-
import requests
import lxml
from bs4 import BeautifulSoup
import xlwt


def craw(url, key_word):
    User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0'
    headers = {

        'Host': 'www.qichacha.com',

        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Connection': 'keep-alive',
        'User-Agent': r'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
        'Cache-Control': 'max-age=0',
        'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
        'Accept-Encoding': 'gzip, deflate',
        'Referer': 'http://www.qichacha.com/search?key=' + key_word,
        'Cookie': r'UM_distinctid=160247c2d6c6c1-0864676ff6c319-323f5c0f-13c680-160247c2d6d7de; _uab_collina=151244062734745712315999; _umdata=70CF403AFFD707DF97AF9224182FA329FEF35B52E6BCF0773789E89BC432F3A33736A9E79B0FDADDCD43AD3E795C914C9A35A17EC4409F89C7058E138F5F054E; PHPSESSID=pmh079nggb14jcog2b4q20f7s4; acw_tc=AQAAAE2NP3cfywMAjyLycpn3IqCCjodH; hasShow=1; zg_did=%7B%22did%22%3A%20%22160247c2d8ba21-092e16f1a4b93-323f5c0f-13c680-160247c2d8c552%22%7D; zg_de1d1a35bfa24ce29bbf2c7eb17e6c4f=%7B%22sid%22%3A%201512549702199%2C%22updated%22%3A%201512549713876%2C%22info%22%3A%201512440606099%2C%22superProperty%22%3A%20%22%7B%7D%22%2C%22platform%22%3A%20%22%7B%7D%22%2C%22utm%22%3A%20%22%7B%7D%22%2C%22referrerDomain%22%3A%20%22www.baidu.com%22%2C%22cuid%22%3A%20%229d5b763efade9b16e31a648ba6203117%22%7D; CNZZDATA1254842228=801840926-1512440140-https%253A%252F%252Fwww.baidu.com%252F%7C1512546679',
        'Cache-Control': 'no-cache',

    }
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        response.encoding = 'utf-8'
        print(response.status_code)
        print('ERROR')
    soup = BeautifulSoup(response.text, 'lxml')
    # print(soup)
    com_names = soup.find_all(class_='ma_h1')  # 获取公司名称
    # print(com_names)
    # com_name1 = com_names[1].get_text()
    # print(com_name1)
    peo_names = soup.find_all(class_='a-blue')  # 公司法人
    # print(peo_names)
    peo_phones = soup.find_all(class_='m-t-xs')  # 公司号码
    # tags = peo_phones[4].find(text = True).strip()
    # print(tags)
    # tttt = peo_phones[0].contents[5].get_text()
    # print (tttt)
    # else_comtent = peo_phones[0].find(class_='m-l')
    # print(else_comtent)
    # peo_emails=soup.find_all(class_='m-1')
    global com_name_list
    global peo_name_list
    global peo_phone_list
    global com_place_list
    global zhuceziben_list
    global chenglishijian_list
    global email_list
    print('开始爬取数据，请勿打开excel')
    for i in range(0, len(com_names)):
        n = 1 + 3 * i
        m = i + 2 * (i + 1)
        try:
            peo_phone = peo_phones[n].find(text=True).strip()
            com_place = peo_phones[m].find(text=True).strip()
            zhuceziben = peo_phones[3 * i].find(class_='m-l').get_text()
            chenglishijian = peo_phones[3 * i].contents[5].get_text()
            email = peo_phones[n].contents[1].get_text()

            # print('email',email)
            peo_phone_list.append(peo_phone)
            com_place_list.append(com_place)
            zhuceziben_list.append(zhuceziben)
            chenglishijian_list.append(chenglishijian)
            email_list.append(email)
        except Exception:
            print('exception')

    for com_name, peo_name in zip(com_names, peo_names):
        com_name = com_name.get_text()
        peo_name = peo_name.get_text()
        com_name_list.append(com_name)
        peo_name_list.append(peo_name)


if __name__ == '__main__':
    com_name_list = []
    peo_name_list = []
    peo_phone_list = []
    com_place_list = []
    zhuceziben_list = []
    chenglishijian_list = []
    email_list = []

    key_word = input('请输入您想搜索的关键词：')
    print('正在搜索，请稍后')
    for x in range(1, 500):
        if x == 1:
            url = r'http://www.qichacha.com/search?key={}#p:{}&'.format(key_word, x)
        else:
            url = r'http://www.qichacha.com/search_index?key={}&ajaxflag=1&p={}&'.format(key_word, x)
        # url = r'http://www.qichacha.com/search?key={}#p:{}&'.format(key_word,x)
        s1 = craw(url, key_word.encode("utf-8").decode("latin1"))
    workbook = xlwt.Workbook()
    # 创建sheet对象，新建sheet
    sheet1 = workbook.add_sheet('xlwt', cell_overwrite_ok=True)
    # ---设置excel样式---
    # 初始化样式
    style = xlwt.XFStyle()
    # 创建字体样式
    font = xlwt.Font()
    font.name = 'Times New Roman'
    font.bold = True  # 加粗
    # 设置字体
    style.font = font
    # 使用样式写入数据
    # sheet.write(0, 1, "xxxxx", style)
    print('正在存储数据，请勿打开excel')
    # 向sheet中写入数据
    name_list = ['公司名字', '法定代表人', '联系方式', '注册人资本', '成立时间', '公司地址', '公司邮件']
    for cc in range(0, len(name_list)):
        sheet1.write(0, cc, name_list[cc], style)
    for i in range(0, len(com_name_list)):
        sheet1.write(i + 1, 0, com_name_list[i], style)  # 公司名字
        sheet1.write(i + 1, 1, peo_name_list[i], style)  # 法定代表人
        sheet1.write(i + 1, 2, peo_phone_list[i], style)  # 联系方式
        sheet1.write(i + 1, 3, zhuceziben_list[i], style)  # 注册人资本
        sheet1.write(i + 1, 4, chenglishijian_list[i], style)  # 成立时间
        sheet1.write(i + 1, 5, com_place_list[i], style)  # 公司地址
        sheet1.write(i + 1, 6, email_list[i], style)  # 邮件地址
    # 保存excel文件，有同名的直接覆盖
    workbook.save(r'D:\test.xls')
    print('the excel save success')
