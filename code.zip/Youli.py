#encoding:utf8
import requests
import time
from selenium import webdriver
from lxml import etree
import re
import csv
import codecs
# import mysql.connector
# db = mysql.connector.connect(host='127.0.0.1', user='root', password='root', port=3306, db='ysh')
# cursor = db.cursor()
dr = webdriver.Chrome()
header = {
    'Referer': 'http://rongyicui.yooli.com//myJob/person/list?loginName=122241001',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
    'Cookie': 'JSESSIONID=4599D68D02690B52C24A2F1F9C616BE2'
}
dr.get(
    'http://cas.yooli.com/cas/login?service=http%3A%2F%2Fsso.yooli.com%2Fsso%2FtsysLoginController.do%3Fmethod%3Dindex')
# print('成功')
# username = ''
# password = ''
# for u in range(1,13):
#     # for i in range(122241001,122241013):
    #     if i <= 122241001:
    #         username = i
    #         password = 'Piao150104'
    #     elif i == '122241005':
    #         username = i
    #         password = 'a123456A'
    #     elif i == '122241009':
    #         username = i
    #         password = 'a123456A'
    #     else:
    #         pass
def youli(username,password):
    userName = dr.find_element_by_id('username').send_keys(username)  # 输入账号
    passWord = dr.find_element_by_id('password').send_keys(password)  # 输入密码
    time.sleep(8)
    click = dr.find_element_by_id('btnSub').click()  # 点击登录
    work = dr.find_element_by_xpath('//*[@id="nav"]/div[1]/div[1]/div[1]').click()  # 点击我的工作
    time.sleep(2)
    mail = dr.find_element_by_xpath('//*[@id="nav"]/div[1]/div[2]/ul/li/div/span[3]').click()  # 点击个人收件箱
    time.sleep(2)
    # iframe1_url = dr.find_element_by_xpath('//*[@id="tabs"]/div[2]/div[1]/div/iframe').get_attribute('src')
    # print(iframe1_url)

    iframe1 = dr.find_element_by_xpath('//*[@class="panel-body panel-body-noheader panel-body-noborder"]/iframe')
    dr.switch_to.frame(iframe1)
    # contents = requests.get(iframe1_url).text
    # result_demo = re.compile('<td align="center">(.*?)</td>', re.S)
    # result = result_demo.findall(contents)
    # print(result)

    max_page = dr.find_element_by_xpath('//*[@id="pagecount"]').text
    # print(max_page)
    max_num = dr.find_element_by_xpath('//*[@id="recordcount"]').text
    int(max_num)
    for page in range(1,int(max_page)+1):
        for i in range(2, int(max_num)+2):
            time.sleep(4)
            dr.switch_to.default_content()  # 因为是循环所以需要再次切换回主页面
            iframe1 = dr.find_element_by_xpath(
                '//*[@class="panel-body panel-body-noheader panel-body-noborder"]/iframe')  # 切换为iframe页面
            dr.switch_to.frame(iframe1)

            ids = dr.find_element_by_xpath(
                '//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[1]/a').get_attribute('href')
            # print(ids)
            ids1 = re.sub("javascript:getThisTask\(", '', ids)
            ids2 = re.sub("\)", '', ids1)
            # print(type(ids1))
            if "\'" in ids2[1:7]:
                ids3 = ids2[1:6]
            else:
                ids3 = ids2[1:7]
            ids4 = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr['+str(i)+']/td[1]/a').text
            # print(ids3, ids4)
            num = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[1]/a').click()  # 第一次点击数字
            customer = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[2]').text
            money = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[3]').text
            start_date = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[4]').text
            overdue_days = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[5]').text
            time_to_enter_personal_inbox = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[6]').text
            recent_call = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[7]').text
            recent_action_code = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[8]').text
            last_follow_up_time = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[9]').text
            process_identification = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[10]').text
            case_type = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[11]').text
            permanent_collector = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[12]').text
            temporary_collector = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[13]').text
            case_level = dr.find_element_by_xpath('//*[@id="response"]/center/table[1]/tbody/tr[' + str(i) + ']/td[14]').text
            # '//*[@id="response"]/center/table[1]/tbody/tr[3]/td[4]'
            home_lists = []
            home_lists.append(num)
            home_lists.append(customer)
            home_lists.append(money)
            home_lists.append(start_date)
            home_lists.append(overdue_days)
            home_lists.append(time_to_enter_personal_inbox)
            home_lists.append(recent_call)
            home_lists.append(recent_action_code)
            home_lists.append(last_follow_up_time)
            home_lists.append(process_identification)
            home_lists.append(case_type)
            home_lists.append(permanent_collector)
            home_lists.append(temporary_collector)
            home_lists.append(case_level)
            print(customer,money,start_date,overdue_days,time_to_enter_personal_inbox,recent_call,recent_action_code,last_follow_up_time,process_identification,case_type,permanent_collector,temporary_collector,case_level)
            filepath = r'D:\home_page_data.csv'
            with open(filepath, 'a+', newline='', encoding='utf8')as e:
                write = csv.writer(e, dialect='excel')
                write.writerow(home_lists)
            e.close()
            time.sleep(3)
            dr.switch_to.frame(1)
            time.sleep(3)
            cookie = [item["name"] + "=" + item["value"] for item in dr.get_cookies()]
            cookiestr = ';'.join(item for item in cookie)
            # print(cookie,cookiestr)
            header = {
                'cookie':cookiestr
            }
            res = requests.get('http://rongyicui.yooli.com:80/info/workspace/form?call_type=&id='+str(ids3)+'&loanNo='+str(ids4)+'&staffNo=&caseBox=&caseStatus=',headers=header)
            # print(res.text)
            tel = requests.get('http://rongyicui.yooli.com/myJob/contactinfo/tel?loanNo='+str(ids4)+'&id='+str(ids3)+'&staffNo=&caseBox=&caseHoldFlag=1&tel=&isIncall=&caseStatus=null&callBackStatus=1',headers=header).text
            # print(tel.text)
            id_s = etree.HTML(tel).xpath('//table[@id="_tb_id"]/tr/td[1]/span/@id')
            print(id_s)
            list_id = []
            for sum1 in id_s:
                sum2 = re.sub('sumSpan_','',sum1)
                # print(sum2)
                list_id.append(sum2)
            for cou in range(0,len(list_id)):
                # list_id[cou]
                # print(list_id[0])
                if money == '0':
                    dat_type = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[2]/text()')[0]
                    phone_num = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[3]/text()')[0]
                    name = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[4]/text()')[0]
                    pepole = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[0])+'"]/td[4]/text()')[0]
                    relationship = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[5]/text()')[0]
                    source = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[6]/text()')[0]
                    count = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[7]/text()')[0]
                    date = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[8]/text()')[0]
                    call_back = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[9]/text()')[0]
                    recently = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[9]/text()')[0]
                    judge = etree.HTML(tel).xpath('//*[@id="tr_'+str(list_id[cou])+'"]/td[11]/text()')[0]
                    lists = []
                    lists.append(phone_num)
                    lists.append(dat_type)
                    lists.append(name)
                    lists.append(pepole)
                    lists.append(relationship)
                    lists.append(source)
                    lists.append(count)
                    lists.append(date)
                    lists.append(call_back)
                    lists.append(recently)
                    lists.append(judge)
                    lists.append(process_identification)
                    print(phone_num, dat_type, name,pepole, relationship, source, count, date, call_back, recently, judge,process_identification)
                # tel_type = re.compile('<td align="center" >(.*?)</td>', re.S)
                # data = tel_type.findall(tel)
                # # print(data)
                # print('-------------------------')
                # for d in data:
                #     print(d)

                    filepath = r'D:\dealt_with_data.csv'
                    with open(filepath, 'a+', newline='', encoding='utf8')as f:
                        write = csv.writer(f, dialect='excel')
                        write.writerow(lists)
                    f.close()
                else:
                    dat_type = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[2]/text()')[0]
                    phone_num = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[3]/text()')[0]
                    name = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[4]/text()')[0]
                    pepole = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[0]) + '"]/td[4]/text()')[0]
                    relationship = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[5]/text()')[0]
                    source = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[6]/text()')[0]
                    count = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[7]/text()')[0]
                    date = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[8]/text()')[0]
                    call_back = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[9]/text()')[0]
                    recently = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[9]/text()')[0]
                    judge = etree.HTML(tel).xpath('//*[@id="tr_' + str(list_id[cou]) + '"]/td[11]/text()')[0]
                    lists = []
                    lists.append(phone_num)
                    lists.append(dat_type)
                    lists.append(name)
                    lists.append(pepole)
                    lists.append(relationship)
                    lists.append(source)
                    lists.append(count)
                    lists.append(date)
                    lists.append(call_back)
                    lists.append(recently)
                    lists.append(judge)
                    lists.append(process_identification)
                    print(phone_num, dat_type, name, pepole, relationship, source, count, date, call_back, recently,judge, process_identification)
                    filepath = r'D:\non_processing_data.csv'
                    with open(filepath, 'a+', newline='', encoding='utf8')as f:
                        write = csv.writer(f, dialect='excel')
                        write.writerow(lists)
                    f.close()
            time.sleep(2)
            # header1 = {
            #     'Cookie':'JSESSIONID=E2633ED69AC35C8937FD7D282D8F0962',
            #     'Host':'rongyicui.yooli.com',
            #     'Upgrade-Insecure-Requests':'1',
            #     'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
            #                  ''
            # }
            # info_1 = 'http://rongyicui.yooli.com/myJob/caseinfo/list?loanNo='+str(ids4)+'&id='+str(ids3)+'&staffNo=&caseBox=&caseHoldFlag=null&tel=null&isIncall=null&caseStatus=&callBackStatus=null'
            info = requests.get('http://rongyicui.yooli.com/myJob/caseinfo/list?loanNo='+str(ids4)+'&id='+str(ids3)+'&staffNo=&caseBox=&caseHoldFlag=null&tel=null&isIncall=null&caseStatus=&callBackStatus=null',headers=header).text
            numbering_demo = re.compile('<input  type="text" name=".*?" id=".*?"  value="(.*?)" size="25">',re.S)
            numbering = numbering_demo.findall(info)
            name_demo = re.compile('<input  type="text" name="custName" id="custName" value="(.*?)" size="25">',re.S)
            name = name_demo.findall(info)
            tel_demo = re.compile('<input  type="text" value="(.*?)" size="25">',re.S)
            tel_num = tel_demo.findall(info)
            special_demo = re.compile('<input  type="text" value="(.*?)" size="75">', re.S)
            special = special_demo.findall(info)
            test = etree.HTML(info).xpath('/html/body/div[3]/div/table[1]/tr[9]/td[2]/input/@value')
            test1 = etree.HTML(info).xpath('/html/body/div[3]/div/table[2]/tr[2]/td[2]/input/@value')
            print(numbering[0],name[0],tel_num,special,test[0],test1[0])
            time.sleep(2)
            # print(tel_num[20])
            time.sleep(2)
            tel_num.pop(20)
            special.pop(0)
            list_info = []
            for t in tel_num:
                list_info.append(t)
                # print(t)
            for s in special:
                list_info.append(s)
                # print(s)
            # print(info)
            list_info.append(numbering[0])
            list_info.append(name[0])
            list_info.append(test[0])
            list_info.append(test1[0])
            print(list_info)
            # print(len(list_info))
            filepath = r'D:\case_information_data.csv'
            with open(filepath, 'a+', newline='', encoding='utf8')as f:
                write = csv.writer(f, dialect='excel')
                write.writerow(list_info)
            f.close()
            dr.switch_to.default_content()
            time.sleep(4)
            mail_one = dr.find_element_by_xpath('//*[@id="nav"]/div[1]/div[2]/ul/li/div/span[3]').click()  # 再次点击个人收件箱回到上次页面
        iframe1 = dr.find_element_by_xpath('//*[@class="panel-body panel-body-noheader panel-body-noborder"]/iframe')  # 切换为iframe页面
      # dr.switch_to.frame(iframe1)
    #   if dr.find_element_by_xpath('//*[@id="response"]/center/table[2]/tbody/tr/td/span/ul/li[10]/a').click().is_active:
    #       dr.find_element_by_xpath('//*[@id="response"]/center/table[2]/tbody/tr/td/span/ul/li[10]/a').click()#点击下一页
    # iframe1 = dr.find_element_by_xpath('//*[@class="panel-body panel-body-noheader panel-body-noborder"]/iframe')  # 切换为iframe页面
    # dr.switch_to.frame(iframe1)
    # dr.find_element_by_xpath('//*[@id="logout"]').click()
    # dr.switch_to.default_content()
    time.sleep(10)
    dr.quit()
if __name__ == '__main__':
    username = input('请输入用户名：')
    password = input('请输入密码：')
    youli(username=username,password=password)